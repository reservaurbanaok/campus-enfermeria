# 📦 Páginas Legales · Campus Profesional Enfermería

Tres páginas HTML standalone (theme dark/tech), listas para subir a tu hosting.

## 🎨 Diseño

Construidas en el mismo lenguaje visual que tu dashboard y tu `privacidad.html` actual:

- **Tipografía:** Sora (display) + DM Sans (body)
- **Paleta:** Dark navy `#0f1623` con acento azul `#3b82f6` → cyan `#06b6d4`
- **Estilo:** Tech profesional, panel-de-control, con glow ambient sutil
- **Identidad:** Coherente con tu dashboard de gestión privado

## 🗂️ Estructura

```
legales/
├── politica-de-privacidad/
│   └── index.html         → https://campusprofesionalenfermeria.com/politica-de-privacidad/
├── terminos-y-condiciones/
│   └── index.html         → https://campusprofesionalenfermeria.com/terminos-y-condiciones/
└── eliminar-datos/
    └── index.html         → https://campusprofesionalenfermeria.com/eliminar-datos/
```

## 🚀 Cómo subirlas

### Opción 1 · cPanel (lo más común)

1. Entrá a tu **cPanel** → Administrador de Archivos
2. Navegá hasta `public_html/`
3. Subí las **tres carpetas completas** (arrastrá y soltá)
4. Listo. Las URLs ya funcionan.

### Opción 2 · FTP (FileZilla, Cyberduck, etc.)

1. Conectate por FTP a tu hosting
2. Andá a `public_html/`
3. Arrastrá las tres carpetas
4. Listo.

### Opción 3 · WordPress (si lo querés mantener adentro)

Si las páginas están en `public_html/`, WordPress no las pisa porque son carpetas
físicas. WordPress solo controla URLs que NO existen como archivo en el servidor.

## ✅ Verificación post-subida

Abrí en tu navegador:

- `https://campusprofesionalenfermeria.com/politica-de-privacidad/`
- `https://campusprofesionalenfermeria.com/terminos-y-condiciones/`
- `https://campusprofesionalenfermeria.com/eliminar-datos/`

Si cargan, **ya podés enviar esas URLs a Meta para destrabar las APIs**.

## 🔧 Tecnologías

- HTML5 semántico
- CSS puro con variables (sin frameworks)
- Google Fonts (Sora + DM Sans)
- Schema.org JSON-LD (datos estructurados para Meta/Google)
- Open Graph + Twitter Card (previews al compartir)
- 100% responsive (móvil-first)
- Sin JavaScript ni dependencias externas
- Cada archivo es totalmente standalone (~25 KB c/u)

## 📝 Personalización rápida

Si necesitás cambiar algo (email, fecha, nombre de marca), abrí cada `index.html` 
en un editor de texto (VS Code, Notepad++, Sublime, etc.) y reemplazá:

| Buscá esto | Reemplazá por |
|---|---|
| `enfermeriaescolarargentina@gmail.com` | Tu nuevo email |
| `Campus Profesional Enfermería` | Tu nuevo nombre |
| `campusprofesionalenfermeria.com` | Tu nuevo dominio |
| `Mayo 2026` | Mes/año actuales |
| `2026-05-01` (en Schema.org) | Fecha ISO actual |

---

Generado: Mayo 2026 · Theme: Dark Tech
